"""VentLab scientific reference implementation."""
